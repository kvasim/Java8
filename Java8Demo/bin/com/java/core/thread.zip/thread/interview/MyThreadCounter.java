package com.java.core.thread.interview;

public class MyThreadCounter implements Runnable  {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}
