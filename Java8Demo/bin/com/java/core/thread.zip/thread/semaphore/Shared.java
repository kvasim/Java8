package com.java.core.thread.semaphore;

public class Shared {
	static int count = 0;
}
