package com.java.core.thread;

public class WaitNotifyExample {
	public static void main(String[] args) {
		ThreadA threadA= new ThreadA();
		threadA.displayTotal();
	}

}
